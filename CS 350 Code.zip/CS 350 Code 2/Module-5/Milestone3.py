#
# Milestone3.py - Completed Python code for Milestone 3. 
#
#------------------------------------------------------------------
# Change History
#------------------------------------------------------------------
# Version   |   Description
#------------------------------------------------------------------
#    1          Initial Development[cite: 13]
#    2          Completed TODO sections for Morse Code State Machine
#------------------------------------------------------------------

from gpiozero import Button, LED
from statemachine import StateMachine, State
from time import sleep

import board
import digitalio
import adafruit_character_lcd.character_lcd as characterlcd

from threading import Thread

DEBUG = True

class ManagedDisplay():
    def __init__(self):
        self.lcd_rs = digitalio.DigitalInOut(board.D17)
        self.lcd_en = digitalio.DigitalInOut(board.D27)
        self.lcd_d4 = digitalio.DigitalInOut(board.D5)
        self.lcd_d5 = digitalio.DigitalInOut(board.D6)
        self.lcd_d6 = digitalio.DigitalInOut(board.D13)
        self.lcd_d7 = digitalio.DigitalInOut(board.D26)

        self.lcd_columns = 16
        self.lcd_rows = 2 

        self.lcd = characterlcd.Character_LCD_Mono(self.lcd_rs, self.lcd_en, 
                    self.lcd_d4, self.lcd_d5, self.lcd_d6, self.lcd_d7, 
                    self.lcd_columns, self.lcd_rows)

        self.lcd.clear()

    def cleanupDisplay(self):
        self.lcd.clear()
        self.lcd_rs.deinit()
        self.lcd_en.deinit()
        self.lcd_d4.deinit()
        self.lcd_d5.deinit()
        self.lcd_d6.deinit()
        self.lcd_d7.deinit()
        
    def clear(self):
        self.lcd.clear()

    def updateScreen(self, message):
        self.lcd.clear()
        self.lcd.message = message

class CWMachine(StateMachine):
    "A state machine designed to display morse code messages"[cite: 13]

    redLight = LED(18)
    blueLight = LED(23)

    message1 = 'SOS'
    message2 = 'OK'
    activeMessage = message1

    endTransmission = False

    off = State(initial = True)
    dot = State()
    dash = State()
    dotDashPause = State()
    letterPause = State()
    wordPause = State()

    screen = ManagedDisplay()

    morseDict = {
        "A" : ".-", "B" : "-...", "C" : "-.-.", "D" : "-..",
        "E" : ".", "F" : "..-.", "G" : "--.", "H" : "....",
        "I" : "..", "J" : ".---", "K" : "-.-", "L" : ".-..",
        "M" : "--", "N" : "-.", "O" : "---", "P" : ".--.",
        "Q" : "--.-", "R" : ".-.", "S" : "...", "T" : "-",
        "U" : "..-", "V" : "...-", "W" : ".--", "X" : "-..-",
        "Y" : "-.--", "Z" : "--..", "0" : "-----", "1" : ".----",
        "2" : "..---", "3" : "...--", "4" : "....-", "5" : ".....",
        "6" : "-....", "7" : "--...", "8" : "---..", "9" : "----.",
        "+" : ".-.-.-", "-" : "-....-", "/" : "-..-.", "=" : "-...-",
        ":" : "---...", "." : ".-.-.-", "$" : "...-..-", "?" : "..--..",
        "@" : ".--.-.", "&" : ".-...", "\"" : ".-..-.", "_" : "..--.-",
        "|" : "--...-", "(" : "-.--.-", ")" : "-.--.-"
    }

    doDot = (
        off.to(dot) | dot.to(off)
    )

    doDash = (
        off.to(dash) | dash.to(off)
    )

    doDDP = (
        off.to(dotDashPause) | dotDashPause.to(off)
    )

    doLP = (
        off.to(letterPause) | letterPause.to(off)
    )

    doWP = (
        off.to(wordPause) | wordPause.to(off)
    )

    def on_enter_dot(self):
        self.redLight.on()
        if(DEBUG):
            print("* Changing state to red - dot")[cite: 13]

    def on_exit_dot(self):
        self.redLight.off()

    def on_enter_dash(self):
        self.blueLight.on()
        if(DEBUG):
            print("* Changing state to blue - dash")[cite: 13]

    def on_exit_dash(self):
        self.blueLight.off()

    def on_enter_dotDashPause(self):
        sleep(0.25)
        if(DEBUG):
            print("* Pausing Between Dots/Dashes - 250ms")[cite: 13]

    def on_exit_dotDashPause(self):
        pass

    def on_enter_letterPause(self):
        sleep(0.75)
        if(DEBUG):
            print("* Pausing Between Letters - 750ms")[cite: 13]

    def on_exit_letterPause(self):
        pass

    def on_enter_wordPause(self):
        sleep(3.0)
        if(DEBUG):
            print("* Pausing Between Words - 3000ms")[cite: 13]

    def on_exit_wordPause(self):
        pass

    def toggleMessage(self):
        self.activeMessage = self.message2 if self.activeMessage == self.message1 else self.message1
        if(DEBUG):
            print(f"* Toggling active message to: {self.activeMessage} ")[cite: 13]

    def processButton(self):
        print('*** processButton')[cite: 13]
        self.toggleMessage()

    def run(self):
        myThread = Thread(target=self.transmit)
        myThread.start()
        
    def transmit(self):
        while not self.endTransmission:
            self.screen.updateScreen(f"Sending:\n{self.activeMessage}")
            wordList = self.activeMessage.split()

            lenWords = len(wordList)
            wordsCounter = 1
            for word in wordList:
            
                lenWord = len(word)
                wordCounter = 1
                for char in word:
                    morse = self.morseDict.get(char)

                    lenMorse = len(morse)
                    morseCounter = 1
                    for x in morse:
                        if x == '.':
                            self.doDot()
                            self.doDot()
                        elif x == '-':
                            self.doDash()
                            self.doDash()

                        if morseCounter < lenMorse:
                            self.doDDP()
                            self.doDDP()
                            morseCounter += 1

                    if wordCounter < lenWord:To complete your `Milestone3.py` script, you need to fill in the `TODO` sections across the `CWMachine` class and the button event assignment at the bottom. 

Here is the breakdown of what goes into each `TODO` block to make your Morse code state machine, LEDs, LCD display, and button toggle function properly.

---

### 1. LED States (`on_enter_dot`, `on_exit_dot`, `on_enter_dash`, `on_exit_dash`)
Inside the `dot` and `dash` state entry and exit methods, turn the respective LED on/off with the required timings:

```python
    def on_enter_dot(self):
        self.redLight.on()
        sleep(0.5)
        if(DEBUG):
            print("* Changing state to red - dot")

    def on_exit_dot(self):
        self.redLight.off()

    def on_enter_dash(self):
        self.blueLight.on()
        sleep(1.5)
        if(DEBUG):
            print("* Changing state to blue - dash")

    def on_exit_dash(self):
        self.blueLight.off()
